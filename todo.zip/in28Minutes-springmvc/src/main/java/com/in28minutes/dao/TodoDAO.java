package com.in28minutes.dao;

import java.util.List;

import com.in28minutes.model.Todo;

public interface TodoDAO {
	public void insertOrUpdate(Todo todo);
	public void delete(int id);
	public Todo get(int id);
	public List<Todo> list();
}
