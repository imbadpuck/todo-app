package com.in28minutes.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;
import com.in28minutes.dao.TodoDAO;
import com.in28minutes.model.Todo;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowMapper;

public class TodoDAOImpl implements TodoDAO {
	

    private JdbcTemplate jdbcTemplate;
    
    public TodoDAOImpl(DataSource dataSource) {
        jdbcTemplate = new JdbcTemplate(dataSource);
    }

	
	@Override
	public void insertOrUpdate(Todo todo) {
			// TODO Auto-generated method stub
		
		    if (todo.getId() > 0) {
		        // update
		        String sql = "UPDATE todo SET user=?, desc=?, targetDate=?, "
		                    + "isDone=? WHERE id=?";
		        jdbcTemplate.update(sql, todo.getUser(), todo.getDesc(),
		                todo.getTargetDate(), todo.isDone(), todo.getId());
		    } else {
		        // insert
		        String sql = "INSERT INTO todo (user, desc, targetDate, isDone)"
		                    + " VALUES (?, ?, ?, ?)";
		        jdbcTemplate.update(sql, todo.getUser(), todo.getDesc(),
		                todo.getTargetDate(), todo.isDone());
		    }
		 
		
	}
	
	@Override
	public void delete(int id) {
		// TODO Auto-generated method stub
	    String sql = "DELETE FROM todo WHERE id=?";
	    jdbcTemplate.update(sql, id);
	}
	
	@Override
	public Todo get(int id) {
		// TODO Auto-generated method stub
	    String sql = "SELECT * FROM todo WHERE id=" + id;
	    return jdbcTemplate.query(sql, new ResultSetExtractor<Todo>() {
	 
	        @Override
	        public Todo extractData(ResultSet rs) throws SQLException,
	                DataAccessException {
	            if (rs.next()) {
	                Todo todo = new Todo();
	                todo.setId(rs.getInt("id"));
	                todo.setUser(rs.getString("user"));
	                todo.setDesc(rs.getString("desc"));
	                todo.setTargetDate(rs.getTimestamp("targetDate"));
	                todo.setDone(rs.getBoolean("isDone"));
	                return todo;
	            }
	 
	            return null;
	        }
	 
	    });
	}
	
	@Override
	public List<Todo> list() {
		// TODO Auto-generated method stub
	    String sql = "SELECT * FROM contact";
	    List<Todo> listTodo = jdbcTemplate.query(sql, new RowMapper<Todo>() {
	 
	        @Override
	        public Todo mapRow(ResultSet rs, int rowNum) throws SQLException {
	            Todo aTodo = new Todo();
	 
	            aTodo.setId(rs.getInt("id"));
	            aTodo.setUser(rs.getString("user"));
	            aTodo.setDesc(rs.getString("desc"));
	            aTodo.setTargetDate(rs.getTimestamp("targetDate"));
	            aTodo.setDone(rs.getBoolean("isDone"));
	 
	            return aTodo;
	        }
	 
	    });
	 
	    return listTodo;
	}
	
	
	
}
